from .base_models import BaseAPIRequestLog


class APIRequestLog(BaseAPIRequestLog):
    pass
