__version__ = '1.7.8'
default_app_config = 'rest_framework_tracking.apps.RestFrameworkTrackingConfig'
