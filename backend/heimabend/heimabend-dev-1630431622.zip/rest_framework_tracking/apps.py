from django.apps import AppConfig


class RestFrameworkTrackingConfig(AppConfig):
    name = 'rest_framework_tracking'
    verbose_name = "REST Framework Tracking"
